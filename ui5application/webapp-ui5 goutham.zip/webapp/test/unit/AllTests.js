sap.ui.define([
	"ui5application/test/unit/controller/Home.controller"
], function () {
	"use strict";
});

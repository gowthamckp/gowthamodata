/* global QUnit */

sap.ui.require(["ui5application/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
